var jours_Ar = ["الاثنين", "الثلاثاء" ,"الاربعاء" , "الخميس" , "الجمعة" , "السبت" ,"الاحد"];

let html = `<table> `;
function init(){
    console.log(jours_Ar[2]);
   for(let i = 0; i<12 ; i++){
    let d = new Date(2021,i,1);
    
    html = html+ `<tr> <td>${jours_Ar[d.getDate()]} </td> <td>${d.getDate()} </td> <td>${i}</td> </tr>`;
    d = d+ new Date(0,1,0);
   }
   html = html + `</table>`;
   let t = document.getElementById("table");
   t.innerHTML = html;
}


onload = init;